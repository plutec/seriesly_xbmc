#Availables players

def available_player(host):
    if host == 'Played.to':
        return True
    elif host == 'allmyvideos':
        return True
    elif host == 'Magnovideo':
        return True
    elif host == 'Vidspot':
        return True
    elif host == 'StreamCloud':
        return True
    return False