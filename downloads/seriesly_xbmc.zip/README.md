seriesly_xbmc
=============

Plugin para utilizar seriesly en XBMC

Este plugin se desarrolló inicialmente para su uso en la RaspberryPi (actualmente utilizo OpenElec con este plugin)

Actualmente está probado y es funcional en las versiones **12.2 (Frodo)** y **12.3**. NO ha sido probada en las versiones 11 ni 13 de XBMC.

En la página **http://www.plutec.net/2014/04/instalar-plugin-xbmc-zip.html** podréis ver un manual de instalación paso a paso del archivo zip. Es un proceso un poco extraño, pero bastante sencillo.

El plugin en versión zip se puede descargar desde aquí: 

**http://bit.ly/sly_xbmc**

o desde aquí:

**https://github.com/plutec/seriesly_xbmc/blob/master/downloads/seriesly_xbmc.zip?raw=true**
