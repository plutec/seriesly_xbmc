seriesly_xbmc
=============

Plugin for seriesly in XBMC


Para XBMC 11 (Eden) no está soportada.

Probado en 12.3 (Frodo)
Probado en 13.0